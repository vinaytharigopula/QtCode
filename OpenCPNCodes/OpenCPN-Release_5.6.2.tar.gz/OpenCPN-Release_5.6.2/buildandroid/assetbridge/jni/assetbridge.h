/*
 * the function prototype
 */

jstring Java_com_arieslabs_assetbridge_Assetbridge_setassetdir(JNIEnv*, jobject, jstring);
