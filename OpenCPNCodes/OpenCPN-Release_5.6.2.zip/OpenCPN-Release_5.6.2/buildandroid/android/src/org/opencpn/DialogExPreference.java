package org.opencpn;
import android.content.Context;
import android.util.AttributeSet;

import android.preference.DialogPreference;

public class DialogExPreference extends DialogPreference
{
    public DialogExPreference(Context oContext, AttributeSet attrs)
    {
        super(oContext, attrs);
    }
}